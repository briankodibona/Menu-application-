public abstract class Order {
    public double totalMenuCost(String burger, int toppingAmount, boolean deluxBurger, String drinkType, String drinkSize
            , String sideItem) {
        Drink drinkObj = new Drink(drinkType, drinkSize);
        double drinkPrice = drinkObj.calculatePrice(drinkSize);
        SideItem sideItem1 = new SideItem(sideItem);
        double sidePrice = sideItem1.calculatePrice(sideItem);
        Burger burger1 = new Burger(burger, toppingAmount, deluxBurger);
        double burgerPrice = burger1.calculatePrice();
        double totalPrice = burgerPrice + sidePrice + drinkPrice;
        return totalPrice;
    }



    public double calculatePrice(String size) {
        return 0;
    }
}

class Drink extends Order{
    private String type;
    private String size;
    private double price;

    public Drink(String type, String size) {
        if (type.isBlank()){ this.type = null;}
        else {this.type = type; }
        if (size.toUpperCase().charAt(0) != 'S'
                || size.toUpperCase().charAt(0) != 'M'
                || size.toUpperCase().charAt(0) != 'L')
        { this.type = null; this.size = null; }
        else {this.size = size; }

    }

    public String getSize() {
        return size;
    }

    public double calculatePrice(){
        return calculatePrice(size);
    }

    @Override
    public double calculatePrice(String size){
       double tempPirce = 0.00;
        if (size != null) {
            switch (size.toUpperCase().charAt(0)) {
                case 'S' -> tempPirce = 9.99;
                case 'M' -> tempPirce = 19.99;
                case 'L' -> tempPirce = 29.99;
                default -> tempPirce = 0;
            }
        }
        return tempPirce;
    }
}

class SideItem extends Order{
    private String type;
    private double price;

    public SideItem(String type) {
        this.type = type;
    }

    public double calculatePrice(){
        return calculatePrice(type);
    }

    @Override
    public double calculatePrice(String sideItem) {
       double tempPrice = 0.00;
        if(sideItem != null){
        switch (sideItem.toUpperCase().charAt(0)) {
            case 'F' -> tempPrice = 2.99;
            case 'O' -> tempPrice = 3.49;
            case 'C' -> tempPrice = 1.99;
            case 'S' -> tempPrice = 3.99;
            case 'M' -> tempPrice = 4.29;
            default -> {
                if (sideItem == null) {
                    tempPrice = 0.0;
                }
            }
          }
        }
            return tempPrice;

    }
}

class Burger extends Order{
    private String type;
    private double price;
    private int amountOfTopping;

    private boolean deluxBurger;


    public Burger(String type, int amountOfTopping, boolean deluxBurger) {
        this.type = type;
        this.amountOfTopping = amountOfTopping;
        this.deluxBurger = deluxBurger;
    }

    public double extraToppings(int amountOfToppings, String topping1){

        double totalTopingCost = extraToppings(amountOfToppings, topping1, null,null);
        return totalTopingCost;
    }
    public double extraToppings(int amountOfToppings, String topping1,
                                String topping2){
        double totalTopingCost = extraToppings(amountOfToppings, topping1, topping2,null);
        return totalTopingCost;
    }

    public double calculatePrice(){
        return calculatePrice(type, deluxBurger, amountOfTopping, null, null, null );
    }

    public double calculatePrice(String burger,boolean isDeluxBurger , int amountOfTopping, String topping1, String topping2, String topping3) {
        double totalCost = 0;
        if(amountOfTopping > 0 && isDeluxBurger == false) {
            totalCost = extraToppings(amountOfTopping, topping1, topping2, topping3);
            //System.out.println(burger.toLowerCase().substring(0,6));
            switch (burger.toLowerCase().substring(0,6)) {
                case "classi" -> totalCost += 6.99;
                case "cheese" -> totalCost += 7.49;
                case "bacon " -> totalCost += 8.49;
                case "mushro" -> totalCost += 8.99;
                case "double" -> totalCost += 9.99;
                default -> totalCost = 0;
            }
        }else if (deluxBurger) { totalCost = 14.00; }
        else if (amountOfTopping == 0){
            switch (burger.toLowerCase().substring(0,6)) {
                case "classi" -> totalCost += 6.99;
                case "cheese" -> totalCost += 7.49;
                case "bacon " -> totalCost += 8.49;
                case "mushro" -> totalCost += 8.99;
                case "double" -> totalCost += 9.99;
                default -> totalCost = 0;
            }
        }

        return totalCost;
    }

    private double extraToppings(int amountOfToppings, String topping1,
                                 String topping2, String topping3){
        double totalCost = 0;
        if (amountOfToppings > 0 && topping1 != null){
                switch (topping1.toUpperCase().charAt(0)) {
                    case 'C' -> totalCost += 0.50;
                    case 'B' -> totalCost += 1.00;
                    case 'G' -> totalCost += 0.75;
                    case 'A' -> totalCost += 1.25;
                    case 'F' -> totalCost += 0.75;
                    default -> totalCost = 0;
                }
                if (topping2 != null) {
                    switch (topping2.toUpperCase().charAt(0)) {
                        case 'C' -> totalCost += 0.50;
                        case 'B' -> totalCost += 1.00;
                        case 'G' -> totalCost += 0.75;
                        case 'A' -> totalCost += 1.25;
                        case 'F' -> totalCost += 0.75;
                        default -> totalCost = 0;
                    }
                }
                if (topping3 != null){
                switch (topping3.toUpperCase().charAt(0)) {
                    case 'C' -> totalCost += 0.50;
                    case 'B' -> totalCost += 1.00;
                    case 'G' -> totalCost += 0.75;
                    case 'A' -> totalCost += 1.25;
                    case 'F' -> totalCost += 0.75;
                    default -> totalCost = 0;
                }
            }
        }

        return totalCost;
    }

}

class MenuItems{

    public void printMenu(){
        System.out.println("""
                Our different type of burgers are:
                 Classic Burger:
                  Description: A simple and classic beef burger with lettuce, tomato, and onions.
                  Price: $6.99
                 
                 
                  Cheeseburger:
                  Description: The classic beef burger with a slice of cheese on top.
                  Price: $7.49
                  
                  Bacon Cheeseburger:
                  Description: The cheeseburger with crispy bacon strips added for extra flavor.
                  Price: $8.49
                  
                 
                  Mushroom Swiss Burger:
                  Description: A beef burger with grilled mushrooms and Swiss cheese, offering a savory combination.
                  Price: $8.99
                  
                  Double Patty Burger:
                  Description: A hearty burger with two beef patties, ideal for those with a big appetite.
                  Price: $9.99""");


        System.out.println("""
                Our extra toppings on the burgers are:
                
                Cheese Slice: $0.50c
                A slice of cheese, like cheddar or Swiss, to add extra flavor to the burger.
                
                Bacon Strips: $1.00
                Crispy bacon strips, a popular choice to enhance the taste of burgers.
                
                Grilled Mushrooms: $0.75
                Sliced mushrooms grilled to perfection, adding a delicious earthy flavor.
                
                Avocado Slices: $1.25            
                Fresh avocado slices, a creamy and nutritious addition to any burger.
                
                Fried Egg: $0.75              
                A fried egg, often served sunny-side-up, to add richness and a delightful twist.""");

        System.out.println("""
                Our different side items are:
                French Fries - $2.99
                
                Onion Rings - $3.49
                
                Coleslaw - $1.99
                
                Sweet Potato Fries - $3.99
                
                Mozzarella Sticks - $4.29
                """);
    }


}
