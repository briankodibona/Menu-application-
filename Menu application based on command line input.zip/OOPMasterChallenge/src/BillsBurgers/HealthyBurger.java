package BillsBurgers;

public class HealthyBurger extends Hamburger {
    private String healthyExtra1Name;
    private double healthyExtra1Price;
    private String healthyExtra2Name;
    private double healthyExtra2Price;
    private double additionPrice1;
    public HealthyBurger(String meat, double price) {
        super("Healthy", meat, price, "brown rye roll");

    }

    @Override
    public void addHamburgerAddition1(String addition1Name, double addition1Price) {
        super.addHamburgerAddition1(addition1Name, addition1Price);
        this.additionPrice1 = addition1Price;
    }

    public void addHealthyAddition1(String addition1Name, double addition1Price){
        this.healthyExtra1Name = addition1Name;
        this.healthyExtra1Price = addition1Price;
        System.out.println("Added " + addition1Name + " for an extra " + addition1Price);
       // return price;
    }

    public void addHealthyAddition2(String addition2Name, double addition2Price){
        this.healthyExtra2Name = addition2Name;
        this.healthyExtra2Price = addition2Price;

        System.out.println("Added " + addition2Name + " for an extra " + addition2Price);
       // return price;
    }

    @Override
    public double itemizeHamburger() {
      //  super("Healthy Hamburger",meat ,totalPrice,"brown rye roll");
        double totalPrice  = 0.00;
        totalPrice += (healthyExtra1Name == null) ? 0 :  healthyExtra1Price;
        totalPrice += (healthyExtra2Name == null) ? 0 : healthyExtra2Price;
        totalPrice += additionPrice1;
        return totalPrice + super.itemizeHamburger();
    }
}
