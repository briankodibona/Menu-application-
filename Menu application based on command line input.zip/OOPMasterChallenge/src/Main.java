public class Main {
    public static void main(String[] args) {
      /*  // Test the MenuItems class
        MenuItems menuItems = new MenuItems();
        menuItems.printMenu();

        // Test the Drink class
        Drink drink1 = new Drink("Coke", "S");
        double drink1Cost = drink1.calculatePrice("small");
        System.out.println("Drink 1 Cost: $" + drink1Cost);

        Drink drink2 = new Drink("Pepsi", "M");
        double drink2Cost = drink2.calculatePrice("medium");
        System.out.println("Drink 2 Cost: $" + drink2Cost);

        Drink drink3 = new Drink("Sprite", "L");
        double drink3Cost = drink3.calculatePrice("Large");
        System.out.println("Drink 3 Cost: $" + drink3Cost);

        // Test the SideItem class
        SideItem sideItem1 = new SideItem("French Fries");
        double sideItem1Cost = sideItem1.calculatePrice();
        System.out.println("Side Item 1 Cost: $" + sideItem1Cost);

        SideItem sideItem2 = new SideItem("Onion Rings");
        double sideItem2Cost = sideItem2.calculatePrice();
        System.out.println("Side Item 2 Cost: $" + sideItem2Cost);

        SideItem sideItem3 = new SideItem("Salad");
        double sideItem3Cost = sideItem3.calculatePrice();
        System.out.println("Side Item 3 Cost: $" + sideItem3Cost);

        // Test the Burger class
        Burger burger1 = new Burger("Classic Burger", 2, false);
        double burger1Cost = burger1.calculatePrice();
        System.out.println("Regular Burger 1 Cost: $" + burger1Cost);

        Burger burger2 = new Burger("Double Patty Burger", 0, true);
        double burger2Cost = burger2.calculatePrice();
        System.out.println("Deluxe Burger Cost: $" + burger2Cost);

        Burger burger3 = new Burger("Bacon Cheeseburger", 3, false);
        double burger3Cost = burger3.calculatePrice();
        System.out.println("Regular Burger 3 Cost: $" + burger3Cost);

        // Calculate the total meal cost
        double totalMealCost = burger1Cost + burger2Cost + drink1Cost + sideItem1Cost;
        System.out.println("Total Meal Cost: $" + totalMealCost);

        System.out.println("_____________");

        burger1Cost = burger1.calculatePrice("Classic Burger", false, 2, "Cheese", "Bacon", null);
        burger2Cost = burger2.calculatePrice("Double Patty Burger", true, 0, null, null, null);
        burger3Cost = burger3.calculatePrice("Bacon Cheeseburger", false, 3, "Mushrooms", "Grilled Onions", "Avocado");
        System.out.printf("Burger 1 costs :$%.2f %nBurger 2 costs:$%.2f %n Burger 3 costs:%.2f %n",burger1Cost,burger2Cost,burger3Cost);*/

        /*Item coke = new Item("drink","coke",1.50);
        coke.printItem();
        coke.setSize("Large");
        coke.printItem();

        Item avocado = new Item("Topping","avocado", 1.50);
        avocado.printItem();*/
/*
        Burger3 burger = new Burger3("regular", 4.00);
        burger.addToppings("BACON", "CHEESE", "MAYO");
        burger.printItem();*/

        /*MealOrder regularMeal = new MealOrder();
        regularMeal.addBurgerToppings("BACON","CHEESE","MAYO");
        regularMeal.setDrinkSize("LARGE");
        regularMeal.printItemizedList();

        MealOrder secondBurger = new MealOrder("turkey", "7-up",
                "chilli");
        secondBurger.addBurgerToppings("LETTUCE", "CHEESE", "MAYO");
        secondBurger.setDrinkSize("SMALL");
        secondBurger.printItemizedList();*/

        MealOrder deluxeMeal = new MealOrder("deluxe", "7-UP",
                "chili");
        deluxeMeal.addBurgerToppings("AVACAOD", "CHEESE", "LETTUCE",
                "BACON", "ONIONS");
        deluxeMeal.setDrinkSize("small");
        deluxeMeal.printItemizedList();

    }
    }

