public class MealOrder {
    private Burger3 burger;
    private Item drink;
    private Item side;

    public MealOrder(){
        this("regular", "coke", "fries");
    }
    public MealOrder(String burgerType,String drinkType, String sideType) {
        if (burgerType.equalsIgnoreCase("deluxe")){
            this.burger = new DeluxBurger(burgerType, 8.5);
        } else {
            this.burger = new Burger3(burgerType, 4.0);
        }
        this.side = new Item("side", sideType, 1.50);
        this.drink = new Item("drink",drinkType, 1.00);
    }

    public double getTotalPrice(){
        if (burger instanceof DeluxBurger){
            return burger.getAdjustedPrice();
        }

        return side.getAdjustedPrice() + drink.getAdjustedPrice() +
                burger.getAdjustedPrice();

    }

    public void printItemizedList(){

        burger.printItem();
        if (burger instanceof DeluxBurger) {
            Item.printItem(drink.getName(), 0);
            Item.printItem(side.getName(), 0);
        }
        else {
            side.printItem();
            drink.printItem();
        }
        System.out.println("-".repeat(30));
        Item.printItem("TOTAL PRICE", getTotalPrice());
    }

    public void addBurgerToppings(String extra1,String extra2, String extra3){
        burger.addToppings(extra1,extra2,extra3);
    }

    public void addBurgerToppings(String extra1,String extra2, String extra3, String extra4, String extra5) {
        if (burger instanceof DeluxBurger db) {
            db.addToppings(extra1, extra2, extra3, extra4, extra5);
        } else {
            burger.addToppings(extra1, extra2, extra3);
        }
    }

    public void setDrinkSize(String size){
        drink.setSize(size);
    }

}

class Item {

    private String type;
    private String name;
    private double price;
    private String size = "MEDIUM";

    public Item(String type, String name, double price) {
        this.type = type.toUpperCase();
        this.name = name.toUpperCase();
        this.price = price;
    }

    public String getName() {
        if (type.equals("SIDE") || type.equals("DRINK")){
            return size + " " + name;
        }
        return name;
    }

    public double getBasePrice() {
        return price;
    }


    public double getAdjustedPrice(){
        return switch (size) {
            case "SMALL" -> getBasePrice() - 0.5;
            case "LARGE" -> getBasePrice() + 1;
            default -> getBasePrice();
        };
    }

    public void setSize(String size) {
        this.size = size;
    }

    public static void printItem(String name, double price){
        System.out.printf("%20s:%6.2f%n", name,price);

    }

    public void printItem(){
        printItem(getName(), getAdjustedPrice());
    }

}

